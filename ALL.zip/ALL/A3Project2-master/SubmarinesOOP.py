import os
import sys
import pygame as pg
import random
from textbox import TextBox
from pygame import mixer

mixer.init()
mixer.music.load("C:/ALL/Space Odyssey 2001 Trap Extended.mp3")
mixer.music.play()

pg.init()
KEY_REPEAT_SETTING = (200,70)
icon = pg.image.load("Chest.png")
white = (255,255,255)
black = (0,0,0)
red = (200,0,0)
light_red = (255,0,0)
yellow = (200,200,0)
light_yellow =(255,255,0)
green = (34,177,76)
light_green = (0,255,0)
blue = (0,0,255)
light_blue = (176,196,222)
display_width = 800
display_height = 600
lootSize = 50
small_font = pg.font.SysFont("comicsansms", 25)
med_font = pg.font.SysFont("comicsansms", 50)
large_font = pg.font.SysFont("comicsansms", 65)
subImg = pg.image.load('Submarine.png')
direction ="right"
loot = [['Chest.png',50,0,0],['Ruby.png',20,0,0],['Gold.png',30,0,0],['Diamond.png',40,0,0],['Silver.png',15,0,0],['Emerald.png',15,0,0],['Saphire.png',25,0,0],['Crown.png',10,0,0]]
treasure = []

class GUI(object):
    def __init__(self):
        pg.display.set_caption("Submarines")
        pg.display.set_icon(icon)
        self.screen = pg.display.set_mode((display_width,display_height))
        self.clock = pg.time.Clock()
        self.fps = 60.0
        self.done = False
        self.retrieved = False
        self.input = TextBox((300,15,150,30),command=self.retrieve_treasure,
                              clear_on_enter=True,inactive_on_enter=False)
        self.color = (light_blue)
        self.prompt = self.make_prompt('Enter treasure to search for:')
        self.subX = display_width/2
        self.subY = display_height/2
        self.subSize = 50
        self.lootSize = lootSize
        self.fuel = 10000
        self.score = 0
        self.treasure_gathered = []
        pg.key.set_repeat(*KEY_REPEAT_SETTING)

    def make_prompt(self,message):
        font = pg.font.SysFont("comicsansms", 20) 
        rend = font.render(message, True, black)
        return (rend, rend.get_rect(topleft=(0,0)))

    def text_objects(self,text,colour,size="small"):
        if size == "small":
            textSurface = small_font.render(text,True,colour)
        elif size == "medium":
            textSurface = med_font.render(text,True,colour)
        elif size == "large":
            textSurface = large_font.render(text,True,colour)
            
        return textSurface, textSurface.get_rect()

    def text_to_button(self,msg,colour,buttonX,buttonY,buttonW,buttonH,size = "small"):
        textSurf, textRect = self.text_objects(msg,colour,size)
        textRect.center = ((buttonX+(buttonW/2)),buttonY+(buttonH/2))
        self.screen.blit(textSurf, textRect)

    def message_to_screen(self,msg,colour,y_displace=0,size="small"):
        textSurf, textRect = self.text_objects(msg,colour,size)
        textRect.center = (int(display_width/2), int(display_height/2)+y_displace)
        self.screen.blit(textSurf, textRect)

    def button(self,text,x,y,width,height,inactive_colour,active_colour,action=None):
        cur = pg.mouse.get_pos()
        click = pg.mouse.get_pressed()
        if x+width>cur[0]>x and y+height>cur[1]>y:
            pg.draw.rect(self.screen,active_colour,(x,y,width,height))
            if click[0] == 1 and action!= None:
                if action == "quit":
                    pg.quit()
                    quit()
                elif action == "controls":
                    self.game_controls()
                elif action == "play":
                    self.main_loop()
                elif action == "main":
                    self.game_intro()      
        else:
            pg.draw.rect(self.screen,inactive_colour,(x,y,width,height))
        self.text_to_button(text,black,x,y,width,height)

    def game_controls(self):
        gcont = True
        while gcont:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    quit()
                    
            self.screen.fill(white)
            self.message_to_screen("Controls",green,-250,size="large")
            self.message_to_screen("Type into the text box the treasure",black,-200)
            self.message_to_screen("you want the submarine to retrieve",black,-170)
            self.button("Play",150,500,100,50,green,light_green,action="play")
            self.button("Main",350,500,100,50,yellow,light_yellow,action="main")
            self.button("Quit",550,500,100,50,red,light_red,action="quit")
            xpos = 50
            ypos = 170
            for i in range(len(loot)):
                lootImg = pg.image.load(loot[i][0])
                text = small_font.render(loot[i][0][:-4]+", Value: "+str(loot[i][1]),True,red)
                self.screen.blit(text, [xpos+75,ypos])
                self.screen.blit(lootImg,(xpos,ypos))
                ypos += 75
                if ypos > 500 - 50:
                    xpos += 400
                    ypos = 170

            pg.display.update()
            self.clock.tick(15)
            
    def game_intro(self):
        intro = True
        while intro:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    quit()
            self.screen.fill(white)
            self.message_to_screen("Welcome to Submarines!",red,-100,size="large")

            self.button("Play",150,500,100,50,green,light_green,action="play")
            self.button("Controls",350,500,100,50,yellow,light_yellow,action="controls")
            self.button("Quit",550,500,100,50,red,light_red,action="quit")

            pg.display.update()
            self.clock.tick(15)

    def submarine(self,subX,subY,direction):
        if direction == "up":
            sub = pg.transform.rotate(subImg,90)
        elif direction == "right":
            sub = subImg
        if direction == "down":
            sub = pg.transform.rotate(subImg,270)
        if direction == "left":
            sub = pg.transform.flip(subImg,True,False)

        self.screen.blit(sub,(subX,subY))

    def display_score(self,score):
        font = pg.font.SysFont("comicsansms", 20)
        text = font.render("Score: "+str(score),True,red)
        self.screen.blit(text, [475,0])
        
    def display_fuel(self,fuel):
        font = pg.font.SysFont("comicsansms", 20)
        text = font.render("Fuel: "+str(fuel),True,red)
        self.screen.blit(text, [600,0])

    def event_loop(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.done = True
            self.input.get_event(event)
            
    def bubbleSort(self):
        for passnum in range(len(treasure)-1,0,-1):
            for i in range(passnum):
                if treasure[i][0]>treasure[i+1][0]:
                    temp = treasure[i]
                    treasure[i] = treasure[i+1]
                    treasure[i+1] = temp
                    
    def binarySearch(self,item):
        first = 0
        last = len(treasure)-1
        found = False
        item.lower()
        while first<=last and not found:
            midpoint = (first+last)//2
            if treasure[midpoint][0][:-4].lower() == item:
                found = True
            else:
                if item < treasure[midpoint][0][:-4].lower():
                    last = midpoint-1
                else:
                    first = midpoint+1
        return found,treasure[midpoint]

    def QuickSort(self,myList,start,end):
        if start < end:
            pivot = self.partition(myList, start, end)
            self.QuickSort(myList, start, pivot-1)
            self.QuickSort(myList, pivot+1, end)
        return myList
    def partition(self,myList, start, end):
        pivot = myList[start][1]
        left = start+1
        right = end
        done = False
        while not done:
            while left <= right and myList[left][1] <= pivot:
                left = left + 1
            while myList[right][1] >= pivot and right >=left:
                right = right -1
            if right < left:
                done= True
            else:
                temp=myList[left]
                myList[left]=myList[right]
                myList[right]=temp
        temp=myList[start]
        myList[start]=myList[right]
        myList[right]=temp
        return right

    def retrieve_treasure(self,id,user_input):
        try:
            speed = 1
            subX = self.subX
            subY = self.subY
            touch = 20
            self.bubbleSort()
            found,item = self.binarySearch(user_input)
            new_game = False
            if found == True:
                while not self.retrieved:
                    if subX+touch<=item[2]:
                        subX += speed
                        direction = "right"
                        self.fuel -= 5
                    elif subX>=item[2]+touch:
                        subX -= speed
                        direction = "left"
                        self.fuel -= 5
                    elif (subX>item[2] and subX<item[2]+touch)or(subX+touch>item[2] and subX+touch<item[2]+touch):
                        if subY+touch<=item[3]:
                            subY += speed
                            direction = "down"
                            self.fuel -= 5
                        elif subY>=item[3]+touch:
                            subY -= speed
                            direction = "up"
                            self.fuel -= 5
                        elif (subY>item[3] and subY<item[3]+touch)or(subY+touch>item[3] and subY+touch<item[3]+touch):
                            self.retrieved = True
                
                    self.screen.fill(self.color)
                    self.screen.blit(*self.prompt)
                    self.input.draw(self.screen)
                    self.display_loot()
                    self.submarine(subX,subY,direction)
                    self.display_fuel(self.fuel)
                    self.display_score(self.score)
                    pg.display.update()
                    self.clock.tick(self.fps)
                    if self.fuel <= 0:
                        new_game = self.GameOver(self.score)
                        break
                
                del treasure[:]
                self.treasure_gathered.append(item)
                if new_game:
                    self.score = 0
                    new_game = False
                else:
                    self.score += item[1]
                    self.subX = subX
                    self.subY = subY 
                self.input.update()
                self.retrieved = False
                self.main_loop()
            else:
                self.prompt = self.make_prompt('Please enter a valid treasure:')
                self.screen.blit(*self.prompt)
        except ValueError:
            print("Please input a valid treasure name.")

    def getRandomLocation(self):
        lootX = round(random.randrange(0, display_width - lootSize))
        lootY = round(random.randrange(60, display_height - lootSize))
        if len(treasure) > 1:
            for i in range(len(treasure)-1):
                if (lootX>treasure[i][2] and lootX<treasure[i][2]+lootSize) or (lootX+lootSize>treasure[i][2] and lootX+lootSize<treasure[i][2]+lootSize):
                    if (lootY>treasure[i][3] and lootY<treasure[i][3]+lootSize) or (lootY+lootSize>treasure[i][3] and lootY+lootSize<treasure[i][3]+lootSize):
                        lootX,lootY = self.getRandomLocation()
            if (lootX>self.subX and lootX<self.subX+self.subSize) or (lootX+lootSize>self.subX and lootX+lootSize<self.subX+self.subSize):
                    if (lootY>self.subY and lootY<self.subY+self.subSize) or (lootY+lootSize>self.subY and lootY+lootSize<self.subY+self.subSize):
                        lootX,lootY = self.getRandomLocation()
        return lootX,lootY
            
    def generate_loot(self):
        for i in range(5):
            item = random.choice(loot)
            duplicate = True
            while duplicate:
                if item in treasure:
                    item = random.choice(loot)
                else:
                    duplicate = False
            treasure.append(item)
            lootX,lootY = self.getRandomLocation()
            treasure[i][2] = lootX
            treasure[i][3] = lootY

    def display_loot(self):
        for i in range(len(treasure)):
            lootImg = pg.image.load(treasure[i][0])
            self.screen.blit(lootImg,(treasure[i][2],treasure[i][3]))

    def GameOver(self,score):
        self.screen.fill(self.color)
        self.screen.blit(*self.prompt)
        self.input.draw(self.screen)
        self.display_fuel(self.fuel)
        self.display_score(self.score)
        font = pg.font.SysFont("comicsansms", 65)
        text = font.render("Game Over",True,red)
        self.screen.blit(text, [250,50])
        font = pg.font.SysFont("comicsansms", 50)
        text = font.render("You scored: "+str(score),True,red)
        self.screen.blit(text, [250,150])
        font = pg.font.SysFont("comicsansms", 25)
        text = font.render("Press C to play again and Q to quit ",True,red)
        self.screen.blit(text, [250,450])
        self.treasure_gathered = self.QuickSort(self.treasure_gathered,0,len(self.treasure_gathered)-1)
        text = font.render("You collected the following treasure:",True,red)
        self.screen.blit(text, [250,250])
        xpos= 0
        ypos= 300
        for i in range(len(self.treasure_gathered)):
            lootImg = pg.image.load(self.treasure_gathered[i][0])
            xpos += 50
            if xpos > display_width - 50:
                xpos = 50
                ypos += 75
            self.screen.blit(lootImg,(xpos,ypos))
        pg.display.update()
        gameOver = True 
        while gameOver == True:
                for event in pg.event.get():
                    if event.type == pg.QUIT:
                        pg.quit()
                        sys.exit()
                        quit()
                        gameOver = False
                    if event.type == pg.KEYDOWN:
                        if event.key == pg.K_q:
                            pg.quit()
                            sys.exit()
                            quit()
                            gameOver = False
                        if event.key == pg.K_c:
                            self.subX = display_width/2
                            self.subY = display_height/2
                            self.fuel = 10000
                            self.score = 0
                            self.treasure_gathered = []
                            gameOver = False

        return True
        
    def main_loop(self):
        self.generate_loot()
        while not self.done:
            self.screen.fill(self.color)
            self.event_loop()
            self.input.update()
            self.input.draw(self.screen)
            self.screen.blit(*self.prompt)
            self.display_score(self.score)
            self.display_loot()
            self.submarine(self.subX,self.subY,direction)
            self.display_fuel(self.fuel)
            self.display_score(self.score)
            pg.display.update()
            self.clock.tick(self.fps)


if __name__ == "__main__":
    app = GUI()
    app.game_intro()
    pg.quit()
    sys.exit()
    quit()
