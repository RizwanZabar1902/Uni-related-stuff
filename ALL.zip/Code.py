import os
import sys
import pygame 
import random
from textbox import TextBox
import tkinter
from tkinter import *
import pyglet
from pyglet import *

class Window(Frame):

    def __init__(self, master = None):
        Frame.__init__(self, master)

        self.master = master

        self.init_window()

    def init_window(self):
        
        self.master.title("Please select one of the following options")
        self.pack(fill = BOTH, expand = 1)

        openButton = Button(self, text = "Open", command = lambda:(os.system("C:/A3Project2-master/SubmarinesOOP.py")))
        openButton.pack(side=LEFT, fill = BOTH, expand = True)
        self.pack(fill = BOTH)

        quitButton = Button(self, text = "Quit", command = self.client_exit)
        quitButton.pack(side=RIGHT, fill = BOTH, expand = True)

    def client_open(self):
        os.system("C:/A3Project2-master/SubmarinesOOP.py")  
    
    def client_exit(self):
        exit()

root = Tk()
app = Window(root)
root.mainloop
